<?php
/**
Plugin name: WP CLI Faker
 */

require_once( "vendor/autoload.php" );
